﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyGame;

namespace plyGameEditor
{
	public class Player3rdPerson_InputDefiner : InputDefiner
	{
		public override List<InputDefinition> DefineInput()
		{
			return new List<InputDefinition>()
			{
				new InputDefinition() {
					category = "Player 3rd Person", name = "ForwardBack Move", screenName1 = "Move Forward", screenName2 = "Move Backward",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { 
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.W, key2 = KeyCode.S } ,
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.UpArrow, key2 = KeyCode.DownArrow } 
					}
				},
				new InputDefinition() {
					category = "Player 3rd Person", name = "LeftRight Move", screenName1 = "Move Right", screenName2 = "Move Left",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { 
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.D, key2 = KeyCode.A } ,
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.RightArrow, key2 = KeyCode.LeftArrow } 
					}
				},
				new InputDefinition() {
					category = "Player 3rd Person", name = "LeftRight Turn", screenName1 = "Turn Right", screenName2 = "Turn Left", active = false,
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { 
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.D, key2 = KeyCode.A } ,
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.RightArrow, key2 = KeyCode.LeftArrow } 
					}
				},
				new InputDefinition() {
					category = "Player 3rd Person", name = "Jump", screenName1 = "Jump",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { 
						new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Space } ,
						new InputBind() { device = InputBind.Device.Gamepad, key1 = KeyCode.JoystickButton3 } 
					}				
				},

				new InputDefinition() {
					category = "Player 3rd Person", name = "Hold to Turn",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Mouse1 } }
				},
				new InputDefinition() {
					category = "Player 3rd Person", name = "Turn Axis",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, mouseAxis = InputBind.MouseAxis.MouseX } }
				},

				new InputDefinition() {
					category = "Player 3rd Person", name = "Gamepad ForwardBack Move", screenName1 = "Move Character",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.Gamepad, gamepadAxis = InputBind.GamepadAxis.Axis2, gamepadInvert = true } }
				},
				new InputDefinition() {
					category = "Player 3rd Person", name = "Gamepad LeftRight Move", screenName1 = "Move Left & Right",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.Gamepad, gamepadAxis = InputBind.GamepadAxis.Axis1 } }
				},
				new InputDefinition() {
					category = "Player 3rd Person", name = "Gamepad LeftRight Turn", screenName1 = "Turn Character",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.Gamepad, gamepadAxis = InputBind.GamepadAxis.Axis4 } }
				},

			};
		}

		// ============================================================================================================
	}
}
