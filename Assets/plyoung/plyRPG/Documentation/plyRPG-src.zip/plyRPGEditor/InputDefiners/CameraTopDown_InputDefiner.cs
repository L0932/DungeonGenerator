﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using plyGame;

namespace plyGameEditor
{
	public class CameraTopDown_InputDefiner : InputDefiner
	{
		public override List<InputDefinition> DefineInput()
		{
			return new List<InputDefinition>()
			{
				new InputDefinition() {
					category = "Camera Top-Down", name = "Hold to Control",
					type = InputDefinition.InputType.Button,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, key1 = KeyCode.Mouse1 } }
				},
				new InputDefinition() {
					category = "Camera Top-Down", name = "Rotate Axis",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, mouseAxis = InputBind.MouseAxis.MouseX } }
				},
				new InputDefinition() {
					category = "Camera Top-Down", name = "Tilt Axis",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, mouseAxis = InputBind.MouseAxis.MouseY } }
				},
				new InputDefinition() {
					category = "Camera Top-Down", name = "Zoom",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.KeyMouse, mouseAxis = InputBind.MouseAxis.ScrollWheel } }
				},

				new InputDefinition() {
					category = "Camera Top-Down", name = "GamepadRotateCam", screenName1 = "Rotate Camera",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.Gamepad, gamepadAxis = InputBind.GamepadAxis.Axis4 } }
				},
				new InputDefinition() {
					category = "Camera Top-Down", name = "GamepadTiltCam", screenName1 = "Tilt Camera",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.Gamepad, gamepadAxis = InputBind.GamepadAxis.Axis5 } }
				},
				new InputDefinition() {
					category = "Camera Top-Down", name = "GamepadZoomCam", screenName1 = "Zoom Camera",
					type = InputDefinition.InputType.Axis,
					binds = new InputBind[] { new InputBind() { device = InputBind.Device.Gamepad, gamepadAxis = InputBind.GamepadAxis.Axis3 } }
				},

			};
		}

		// ============================================================================================================
	}
}
