﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyCommon;
using plyBloxKit;

namespace plyGame
{
	public class ItemFieldData : IBlockValidate
	{
		public string id = ""; // unique id
		public string cachedName = "";

		public override string ToString()
		{
			if (string.IsNullOrEmpty(cachedName)) return "-invalid-";
			return string.IsNullOrEmpty(cachedName) ? "-invalid-" : cachedName;
		}

		public ItemFieldData Copy()
		{
			ItemFieldData o = new ItemFieldData();
			o.id = this.id;
			o.cachedName = this.cachedName;
			return o;
		}

		public bool IsValid()
		{
			return (false == string.IsNullOrEmpty(id));
		}

		// ============================================================================================================
	}
}