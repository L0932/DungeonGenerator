﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Control (plyRPG)", "Request MoveTo", BlockType.Action, Order = 5,
		Description = "Ask the character to move to the specified location.")]
	public class Character_RequestMoveTo_plyBlock : plyBlock
	{
		[plyBlockField("Request", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has a plyGame Character Controller component.")]
		public GameObject_Value target;

		[plyBlockField("move to", ShowName = true, ShowValue = true, DefaultObject = typeof(Vector3_Value), SubName = "World Position - Vector3", Description = "")]
		public Vector3_Value location;

		[plyBlockField("Run", Description = "A hint to the character controller to tell it the character should move faster if running is supported.")]
		public bool run = false;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private CharacterControllerBase character = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = location != null;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			if (!blockIsValid) Log(LogType.Error, "The location field must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			
			
				if (character == null)
				{
					GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
					if (o != null)
					{
						character = o.GetComponent<CharacterControllerBase>();
						if (character == null)
						{
							blockIsValid = false;
							Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Character Controller on it.");
							return BlockReturn.Error;
						}
					}
				}

				character.RequestMoveTo(location.RunAndGetVector3(), run);

				if (false == cacheTarget) character = null;
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}