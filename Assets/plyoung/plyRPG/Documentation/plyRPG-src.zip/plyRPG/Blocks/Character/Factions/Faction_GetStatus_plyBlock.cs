﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Factions (plyRPG)", "Get Status", BlockType.Variable, Order = 15, ShowName = "Get Status", ShowIcon = "faction", 
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(GameObject_Value), CustomStyle = "Int_Value",
		Description = "Get the Status (relation) of one Faction towards another. Returns one of the following integer values\n1 = Friendly\n2 = Neutral\n3 = Hostile")]
	public class Faction_GetStatus_plyBlock : Int_Value
	{
		[plyBlockField("of", ShowIfTargetFieldInvalid = "faction1", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", SubName = "Faction ident - String", Description = "The Faction to get the status of. You can choose to either select it from a list or to find it via an ident type. Select 'none' in the list to see a field on the Block into which you can put a String Block which identifies the Faction to find.")]
		public String_Value factionIdent1;

		[plyBlockField("of Faction", CustomValueStyle = "plyBlox_BoldLabel")]
		public FactionFieldData faction1 = new FactionFieldData();

		[plyBlockField("Faction ident type", ShowIfTargetFieldInvalid = "faction1", Description = "What kind of value are you using to identify the Faction by? Only needed if you did not pick the Faction from a List.")]
		public plyGameObjectIdentifyingType identType1 = plyGameObjectIdentifyingType.screenName;

		[plyBlockField("towards", ShowIfTargetFieldInvalid = "faction2", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", EmptyValueName = "-invalid-", SubName = "Target Faction ident - String", Description = "The Faction towards which the status should be returned. You can choose to either select it from a list or to find it via an def.ident type. Select 'none' in the list to see a field on the Block into which you can put a String Block which identifies the Faction to find.")]
		public String_Value factionIdent2;

		[plyBlockField("towards Faction", ShowName = false, ShowValue = false, CustomValueStyle = "plyBlox_BoldLabel")]
		public FactionFieldData faction2 = new FactionFieldData();

		[plyBlockField("Target ident type", ShowIfTargetFieldInvalid = "faction2", Description = "What kind of value are you using to identify the Target Faction by? Only needed if you did not pick the Faction from a List.")]
		public plyGameObjectIdentifyingType identType2 = plyGameObjectIdentifyingType.screenName;

		private UniqueID id1;
		private UniqueID id2;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;

			if (string.IsNullOrEmpty(faction1.id))
			{
				if (factionIdent1 == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Faction 1 is not set.");
					return;
				}
			}
			else
			{
				id1 = new UniqueID(faction1.id); 
				factionIdent1 = null; // make sure is null since I use it for test later
			}

			if (string.IsNullOrEmpty(faction2.id))
			{
				if (factionIdent2 == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "Faction 2 is not set.");
					return;
				}
			}
			else
			{
				id2 = new UniqueID(faction2.id);
				factionIdent2 = null; // make sure is null since I use it for test later
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			ActorFaction f1 = null;
			ActorFaction f2 = null;

			if (factionIdent1 != null) f1 = ActorFactionManager.Instance.GetRuntimeByIdent(factionIdent1.RunAndGetString(), identType1);
			else f1 = ActorFactionManager.Instance.GetRuntimeById(id1);
			if (f1 == null)
			{
				Log(LogType.Error, "Faction 1 not found");
				blockIsValid = false;
				return BlockReturn.Error;
			}

			if (factionIdent2 != null) f2 = ActorFactionManager.Instance.GetRuntimeByIdent(factionIdent2.RunAndGetString(), identType2);
			else f2 = ActorFactionManager.Instance.GetRuntimeById(id2);
			if (f2 == null)
			{
				Log(LogType.Error, "Faction 2 not found");
				blockIsValid = false;
				return BlockReturn.Error;
			}

			StatusTowardsOther st = f1.GetStatusTowards(f2);
			if (st == StatusTowardsOther.Friendly) value = 1;
			else if (st == StatusTowardsOther.Neutral) value = 2;
			else if (st == StatusTowardsOther.Hostile) value = 3;			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}