﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Common (plyRPG)", "Is Actor", BlockType.Condition, Order = 1,
		ReturnValueString = "Return - Boolean", ReturnValueType = typeof(Bool_Value),
		Description = "Returns True if the GameObject is an Actor (Character), else False.")]
	public class Is_Actor_plyBlock : Bool_Value
	{
		[plyBlockField("target", ShowAfterField = "is Actor", ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The GameObject to check.")]
		public GameObject_Value target;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
			if (go != null)
			{
				Actor chara = go.GetComponent<Actor>();
				if (chara != null)
				{
					value = true;
					return BlockReturn.OK;
				}
			}

			value = false;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}