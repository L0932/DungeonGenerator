﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Action Slot (plyRPG)", "Equipped Type", BlockType.Variable, Order = 7,
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns an Integer, indicating whether (-1) Error, (0) Nothing, (1) a Skill, or (2) an Item is in the Action Slot.")]
	public class Ac_GetType_plyBlock : Int_Value
	{
		[plyBlockField("Type in ActionSlot", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Slot Number - Integer", Description = "Slot number to check. Slots starts at number 0.")]
		public Int_Value slotVal;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a player object.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private PlayerBaseController player = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = slotVal != null;
			if (!blockIsValid) Log(LogType.Error, "The slot number field must be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (player == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					player = o.GetComponent<PlayerBaseController>();
					if (player == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Player Controller on it.");
						return BlockReturn.Error;
					}
				}
			}

			value = (int)player.actionSlots.EquippedType(slotVal.RunAndGetInt());
			if (value < 0)
			{
				Log(LogType.Error, "Error while trying to get equipped type on action slot.");
				return BlockReturn.Error;
			}

			if (false == cacheTarget) player = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}