﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Control (plyRPG)", "(dis)Enable Control", BlockType.Action, Order = 5,
		Description = "Set control of the character, via Player Input or AI, enabled or disabled.")]
	public class Character_DisEnableControl_plyBlock : plyBlock
	{
		[plyBlockField("state", ShowValue = true)]
		public plyEnabledState enable = plyEnabledState.Enabled;

		[plyBlockField("control of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has a plyGame Character Controller component.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private CharacterControllerBase character = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (character == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					character = o.GetComponent<CharacterControllerBase>();
					if (character == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Character Controller on it.");
						return BlockReturn.Error;
					}
				}
			}

			character.EnableControl(enable == plyEnabledState.Enabled);
			if (false == cacheTarget) character = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}