﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Control (plyRPG)", "Get Selected", BlockType.Variable, Order = 5, ShowName = "Get selected",
		ReturnValueString = "Return - GameObject", ReturnValueType = typeof(GameObject_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Gets the current target (selected) object of the Actor (Character).")]
	public class Character_GetSelected_plyBlock : GameObject_Value
	{
		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has a plyGame Character Controller component, like the Player or NPC Controllers.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private CharacterControllerBase character = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			
			
				if (character == null)
				{
					GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
					if (o != null)
					{
						character = o.GetComponent<CharacterControllerBase>();
						if (character == null)
						{
							blockIsValid = false;
							Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Character Controller on it.");
							return BlockReturn.Error;
						}
					}
				}

				value = character.selectedTarget == null ? null : character.selectedTarget.gameObject;

				if (false == cacheTarget) character = null;
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}