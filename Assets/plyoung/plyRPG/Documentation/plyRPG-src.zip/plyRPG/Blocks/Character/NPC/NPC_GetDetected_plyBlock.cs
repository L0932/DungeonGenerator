﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "NPC (plyRPG)", "Get Detected", BlockType.Variable, Order = 10, ShowName = "Get detected",
		ReturnValueString = "Return - GameObject", ReturnValueType = typeof(GameObject_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns the detected character that is at the specified index in the list of detected character. Detected characters are sorted from closest to furthest from the NPC. The list of detected characters is only updated when the NPC does detection so the bets place to use this is ion the `NPC > On Detected Characters` as the list is not continuously updated for other events.")]
	public class NPC_GetDetected_plyBlock : GameObject_Value
	{
		[plyBlockField("number", ShowValue = true, DefaultObject = typeof(Int_Value), EmptyValueName = "-invalid-", SubName = "Target - GameObject", Description = "The index into the list of detected characters. Indexing starts at 0 and the list is as big as the value returned by the 'Last Detected Total' Block.")]
		public Int_Value idx;

		[plyBlockField("from", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a Non-Player Character (Have NPC controller on it).")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private NPCController npc = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (npc == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null) npc = o.GetComponent<NPCController>();
				if (npc == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find any NPC Controller component on it.");
					return BlockReturn.Error;
				}

			}

			int i = idx.RunAndGetInt();
			CharacterControllerBase detectedChara = npc.GetDetected(i);
			if (detectedChara == null)
			{
				blockIsValid = false;
				Log(LogType.Error, "The detected at index " + i + " is -null-. You are either checking the list too late or checking at an index that is not present in the list.");
				return BlockReturn.Error;
			}
			else
			{
				value = detectedChara.gameObject;
			}

			if (false == cacheTarget) npc = null; // do not cache
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}