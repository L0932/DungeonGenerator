﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Actor (plyRPG)", "Get Level", BlockType.Variable, Order = 4, ShowName = "Get Level",
		ReturnValueString = "Return - Integer", ReturnValueType = typeof(Int_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Returns the Actor's Level.")]
	public class ActorLevel_Get_plyBlock : Int_Value
	{
		[plyBlockField("from", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has Actor component.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		private void GetActor()
		{
			GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
			if (o != null)
			{
				actor = o.GetComponent<Actor>();
				if (actor == null)
				{
					blockIsValid = false;
					Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor component on it.");
					return;
				}
			}
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GetActor();
				if (false == blockIsValid) return BlockReturn.Error;
			}

			value = actor.actorClass.currLevel;

			if (false == cacheTarget) actor = null; // do not cache
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}