﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Character", "Action Slot (plyRPG)", "Get Equipped Info", BlockType.Variable, Order = 7, ShowName = "Get Equipped Info",
		ReturnValueString = "Return - SystemObject", ReturnValueType = typeof(SystemObject_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns a reference to the equipped Item Prefab or Skill definition. This should not be used to consume an Item or execute a Skill as the returned object reference is that of the definition and not the Player's Skill object or the Item in a bag. Return null if nothing in the slot.")]
	public class Ac_GetEquipNfo_plyBlock : SystemObject_Value
	{
		[plyBlockField("from ActionSlot", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Slot Number - Integer", Description = "Slot number to check. Slots starts at number 0.")]
		public Int_Value slotVal;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a player object.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private PlayerBaseController player = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = slotVal != null;
			if (!blockIsValid) Log(LogType.Error, "The slot number field must be set.");
			if (target == null) cacheTarget = true;
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (player == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					player = o.GetComponent<PlayerBaseController>();
					if (player == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Player Controller on it.");
						return BlockReturn.Error;
					}
				}
			}

			value = player.actionSlots.GetEquippedNfo(slotVal.RunAndGetInt());

			if (false == cacheTarget) player = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}