﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Actor (plyRPG)", "Level to XP", BlockType.Variable, Order = 4,
		ReturnValueString = "Return - Float", ReturnValueType = typeof(Float_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Returns how much XP the Actor needs to reach the given Level. This is the total XP needed.")]
	public class Get_XPNeeded_plyBlock : Float_Value
	{
		[plyBlockField("Level", ShowName = true, ShowValue = true, DefaultObject=typeof(Int_Value), SubName = "Level - Integer", Description = "The Level to check.")]
		public Int_Value lv;

		[plyBlockField("on", ShowAfterField="to XP Value", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has Actor component.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private Actor actor = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = lv != null;
			if (!blockIsValid) Log(LogType.Error, "Level should be set.");
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (actor == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					actor = o.GetComponent<Actor>();
					if (actor == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Actor component on it.");
						return BlockReturn.Error;
					}
				}
			}

			value = actor.actorClass.LevelToXP(lv.RunAndGetInt());

			if (false == cacheTarget) actor = null; // do not cache
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}