﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "Control (plyRPG)", "Set Move Speed", BlockType.Action, Order = 5,
		Description = "Set the movement speed of the target character. You can specify a target character if this block is not used in a Blox that is part of the character object.")]
	public class CharacterMoveSpeed_Set_plyBlock : plyBlock
	{
		[plyBlockField("Set Move Speed of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be object that has a plyGame Character Controller component.")]
		public GameObject_Value target;

		[plyBlockField("to", ShowName = true, ShowValue = true, DefaultObject = typeof(Float_Value), SubName = "Value - Float", Description = "")]
		public Float_Value speed;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private CharacterControllerBase character = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = speed != null;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			if (!blockIsValid) Log(LogType.Error, "The Speed field must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (character == null)
			{
				GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (o != null)
				{
					character = o.GetComponent<CharacterControllerBase>();
					if (character == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any plyGame related Character Controller on it.");
						return BlockReturn.Error;
					}
				}
			}

			character.SetMoveSpeed(speed.RunAndGetFloat());

			if (false == cacheTarget) character = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}