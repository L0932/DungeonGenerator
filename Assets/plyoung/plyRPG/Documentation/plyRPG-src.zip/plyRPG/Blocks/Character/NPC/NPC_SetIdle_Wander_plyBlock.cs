﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("Character", "NPC (plyRPG)", "Idle: Wander", BlockType.Action, Order = 10,
		Description = "Set the target NPC to Wander around its spawn point when it is in 'idle' mode (not chasing something)")]
	public class NPC_SetIdle_Wander_plyBlock : plyBlock
	{
		[plyBlockField("Set", ShowAfterField="to: Wander", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "Should be a Non-Player Character (Have NPC controller on it).")]
		public GameObject_Value target;

		[plyBlockField("around point", ShowName = true, ShowValue = true, EmptyValueName = "-none-", SubName = "Point - Vector3", Description = "You can optionally change the point around which the NPC will wander (changing its assumed spawn point location)")]
		public Vector3_Value newPoint;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private NPCController npc = null;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			stopAllOnError = false;
			blockIsValid = true;
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
		}

		public override BlockReturn Run(BlockReturn param)
		{
			
			
				if (npc == null)
				{
					GameObject o = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
					if (o != null) npc = o.GetComponent<NPCController>();
					if (npc == null)
					{
						blockIsValid = false;
						Log(LogType.Error, "The Target is invalid. Could not find any NPC Controller component on it.");
						return BlockReturn.Error;
					}

				}

				npc.Stop();

				if (newPoint != null)
				{
					npc.spawnLocation = newPoint.RunAndGetVector3();
				}

				npc.idleMode = NPCController.IdleMode.Wander;

				if (false == cacheTarget) npc = null; // do not cache
			
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}