﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Bag (plyRPG)", "Get Item in Slot", BlockType.Variable, Order = 3, ShowName = "Get Item from",
		ReturnValueString = "Return - System.Object", ReturnValueType = typeof(SystemObject_Value), CustomStyle = "plyBlox_VarYellowDark",
		Description = "Get the Item in specified slot. Will return empty/ null value if no Item in Slot. If Items can be stacked then the 1st of the stack in the specified slot will be returned.")]
	public class Bag_GetInBagSlot_plyBlock : SystemObject_Value
	{
		[plyBlockField("Bag Slot", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Slot - Integer", Description = "Slot to look in.")]
		public Int_Value slot;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has a bag.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ItemBag bag;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = slot != null;
			if (!blockIsValid) Log(LogType.Error, "The Slot must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (bag == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				bag = go.GetComponent<ItemBag>();
				if (bag == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Item Bag component on it.");
					return BlockReturn.Error;
				}
			}

			int i = slot.RunAndGetInt();
			ItemBag.ItemInBag iib = bag.GetItemInSlot(i);
			value = iib == null ? null : iib.item;

			if (!cacheTarget) bag = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}