﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Bag (plyRPG)", "Add to Bag", BlockType.Action, Order = 3,
		Description = "Add specified Item to a Bag.")]
	public class Bag_AddItem_plyBlock : plyBlock
	{
		[plyBlockField("Add", ShowAfterField = "copies", ShowName = true, ShowValue = true, EmptyValueName = "-1-", SubName = "Count - Integer", Description = "How many copies of this Item to add. Will silently fail when you try to add more than one copy of an Item but there was not enough space to add all to bag.")]
		public Int_Value copies;

		[plyBlockField("of Item", ShowAfterField = "to Bag", ShowName = true, ShowValue = true, DefaultObject = typeof(Item_plyBlock), SubName = "Item - SystemObject", Description = "The Item to add.")]
		public SystemObject_Value it;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has a bag.")]
		public GameObject_Value target;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ItemBag bag;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = it != null;
			if (!blockIsValid) Log(LogType.Error, "The Item field should be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			// ** Get reference to Bag
			if (bag == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				bag = go.GetComponent<ItemBag>();
				if (bag == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Item Bag component on it.");
					return BlockReturn.Error;
				}
			}

			Item item = it.RunAndGetSystemObject() as Item;
			if (item == null)
			{
				Log(LogType.Error, "The Item value is invalid. Nothing added to Bag.");
				return BlockReturn.Error;
			}

			int count = copies == null ? 1 : copies.RunAndGetInt();

			if (count == 1)
			{
				if (false == bag.AddItemToBag(item))
				{
					Log(LogType.Warning, "Failed to add Item to Bag. There might not be space.");
				}
			}
			else
			{
				bag.AddItemToBag(item, count);
			}

			if (!cacheTarget) bag = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}