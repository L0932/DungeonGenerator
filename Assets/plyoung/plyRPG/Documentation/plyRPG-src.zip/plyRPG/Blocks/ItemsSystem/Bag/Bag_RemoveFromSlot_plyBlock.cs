﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Items", "Bag (plyRPG)", "Remove from Bag Slot", BlockType.Action, Order = 3, ShowName = "Remove Item from",
		Description = "Removes an Item from specified Bag Slot. Will remove one copy of Item if there is a stack in the slot.")]
	public class Bag_RemoveFromSlot_plyBlock : plyBlock
	{
		[plyBlockField("Bag Slot", ShowName = true, ShowValue = true, DefaultObject = typeof(Int_Value), SubName = "Slot - Integer", Description = "Slot to remove Item from.")]
		public Int_Value slot;

		[plyBlockField("of", ShowName = true, ShowValue = true, EmptyValueName = "-self-", SubName = "Target - GameObject", Description = "The target object that has a bag.")]
		public GameObject_Value target;

		[plyBlockField("drop option", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", Description = "What should be done with removed Item.")]
		public ItemBag.ItemDropOption dropOpt = ItemBag.ItemDropOption.toScene;

		[plyBlockField("Cache target", Description = "Tell plyBlox if it can cache a reference to the Target Object, if you know it will not change, improving performance a little. This is done either way when the target is -self-")]
		public bool cacheTarget = false;

		private ItemBag bag;

		public override void Created()
		{
			GameGlobal.Create(); // make sure Global is available
			if (target == null) cacheTarget = true; // force caching when target is null (-self-)
			blockIsValid = slot != null;
			if (!blockIsValid) Log(LogType.Error, "The Slot must be set.");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (bag == null)
			{
				GameObject go = target == null ? owningBlox.gameObject : target.RunAndGetGameObject();
				if (go == null)
				{
					Log(LogType.Error, "The Target is invalid.");
					return BlockReturn.Error;
				}

				bag = go.GetComponent<ItemBag>();
				if (bag == null)
				{
					Log(LogType.Error, "The Target is invalid. Could not find Item Bag component on it.");
					return BlockReturn.Error;
				}
			}

			int i = slot.RunAndGetInt();
			if (false == bag.RemoveItemFromBag(i, dropOpt, true))
			{
				Log(LogType.Warning, "Failed to remove Item from Bag Slot: " + i);
			}

			if (!cacheTarget) bag = null;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}