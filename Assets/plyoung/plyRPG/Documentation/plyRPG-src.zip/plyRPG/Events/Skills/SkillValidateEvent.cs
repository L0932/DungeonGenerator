﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Skill", "On Validate",
		Description = "Called when a skill is about to be activated. This Event should return a Boolean Value. True: The Skill may activate; False: The Skill should not be activated. \n\nThe following Temporary Variables will be set:\n\n"+
		"- <b>skillOwner</b>: The Actor (GameObject) that owns the Skill.\n"+
		"- <b>skillObject</b>: The Skill (GameObject).\n" +
		"- <b>skillOwnerData</b>: Data (System.Object) of owner. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"+
		"- <b>skillData</b>: Data (System.Object) of skill. This can be used with the data retrieval Blocks to get info like ident, name, meta, etc.\n"
	)]
	public class SkillValidateEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Skills);
		}

		// ============================================================================================================
	}
}