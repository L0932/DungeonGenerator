﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Object", "On Interact Stopped",
		Description = "Called when a Character stopped Interaction with this Object. This is normally only used to check when the Player stops interaction. This Event will trigger in Blox on the Object and child objects of it. \n\nThe following Temporary Variables will be set:\n\n" +
		"- <b>character</b>: GameObject of the character (actor) that stopped interacting with this object.\n" +
		"- <b>characterData</b>: Data (System.Object) of the character. This can be used with the data retrieval Blocks to get info like def.ident, name, def.meta, etc.\n"
		)]
	public class ObjectOnInteractStoppedEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_ObjectInteract);
		}

		// ============================================================================================================
	}
}