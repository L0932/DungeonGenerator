﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/PlayerManager", "On Player Created",
		Description = "Called when the Player Manager created/ instantiated the Player Character object. The event us triggered in the Blox of the PlayeManager only."
	)]
	public class PM_PlayerCreatedEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_PlayerManager);
		}

		// ============================================================================================================
	}
}