﻿// -= plyGame =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyEvent("plyRPG/Items", "On Add Currency",
		Description = "Called when Currency is Added to the Bag. The event is only called in the plyBlox on an object with the Item Bag component on it." +
		"\n\nThe following Temporary Variables will be set:\n\n" +
		"- <b>amount</b>: The amount of currency.\n" +
		"- <b>owner</b>: The owner (GameObject) of the bag the Item was added to.\n"
		)]
	public class OnAddCurrencyToBagEvent : plyEvent
	{

		public override System.Type HandlerType()
		{
			return typeof(EventHandler_Item);
		}

		// ============================================================================================================
	}
}