﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;
using plyCommon;

namespace plyGame
{
	[plyBlock("Object", "plyGame", "Get Object Sprite", BlockType.Variable, Order = 1, ShowName = "Get",
		ReturnValueString = "Return - Unity.Object", ReturnValueType = typeof(UnityObject_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Returns sprite of an object from its common definition data (ident, screenName, shortName, meta, etc).")]
	public class Get_ObjectSprite_plyBlock : UnityObject_Value
	{
		public enum ImageNumber { Image1 = 0, Image2 = 1, Image3 = 2 };
		[plyBlockField("Sprite", ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel", SubName = "Sprite Number", Description = "The sprite to get. There are normally 3 different sprites available.")]
		public ImageNumber imgNum = ImageNumber.Image1;

		[plyBlockField("from", ShowName = true, ShowValue = true, EmptyValueName = "-invalid-", SubName = "Target - Object", Description = "Should be an object that has this kind of data available, like Item, Skill, Attribute, etc.")]
		public plyValue_Block target;

		public override void Created()
		{
			blockIsValid = target != null;
			if (!blockIsValid) Log(LogType.Error, "The Target must be set");
		}

		public override BlockReturn Run(BlockReturn param)
		{
			System.Object obj = target.RunAndGetValue();
			if (obj == null)
			{
				Log(LogType.Error, "The specified object was null.");
				value = null;
				return BlockReturn.Error;
			}

			CommonDefinitionData def = plyReflectionUtil.GetFieldValue(obj, "def") as CommonDefinitionData;
			if (def == null)
			{
				Log(LogType.Error, "Could not find Common Definition Data on target.");
				value = null;
				return BlockReturn.Error;
			}

			int idx = (int)imgNum;
			value = def.sprites[idx];

			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}