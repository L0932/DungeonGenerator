﻿// -= plyBlox =-
// www.plyoung.com
// Copyright (c) Leslie Young
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using plyBloxKit;

namespace plyGame
{
	[plyBlock("GUI", "Screens (plyGame)", "Get Text", BlockType.Variable, Order = 10,
		ReturnValueString = "Return - String", ReturnValueType = typeof(String_Value),
		CustomStyle = "plyBlox_VarYellowDark", Description = "Get text from the Text Edit Element.")]
	public class ScreensEle_GetText_plyBlock : String_Value
	{
		[plyBlockField("Get Text from", ShowName = true, ShowValue = true, EmptyValueName="-invalid-", CustomValueStyle = "plyBlox_BoldLabel", Description="Name of the element as defined in the Screens Editor.")]
		public string eleName = "";

		[plyBlockField("on", ShowName = true, ShowValue = true, CustomValueStyle = "plyBlox_BoldLabel")]
		public ScreenDefNameTextData screen = new ScreenDefNameTextData();

		private OnGUIEdit ele;

		public override void Created()
		{
			value = "";
			GameGlobal.Create(); // make sure Global is available
			blockIsValid = !string.IsNullOrEmpty(screen.name);
			if (!blockIsValid) { Log(LogType.Error, "Screen name must be set."); return; }
			blockIsValid = !string.IsNullOrEmpty(eleName);
			if (!blockIsValid) { Log(LogType.Error, "Element name must be set."); return; }
		}

		public override BlockReturn Run(BlockReturn param)
		{
			if (!GameGlobal.Instance.uiManager.screensSystemReady)
			{
				Log(LogType.Warning, "The screen system is not yet ready. You are making calls too early.");
				return BlockReturn.OK;
			}

			if (ele == null)
			{
				GUIScreen scr = GameGlobal.Instance.uiManager.GetScreen(screen.name);
				if (scr == null)
				{
					Log(LogType.Error, "The screen [" + screen.name + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}

				OnGUIElement e = scr.GetElement(eleName);
				if (e == null)
				{
					Log(LogType.Error, "The element [" + eleName + "] was not found.");
					blockIsValid = false;
					return BlockReturn.Error;
				}

				ele = e as OnGUIEdit;
				if (ele == null)
				{
					Log(LogType.Error, "The element is not an Edit type.");
					blockIsValid = false;
					return BlockReturn.Error;
				}
			}

			value = ele.text;
			return BlockReturn.OK;
		}

		// ============================================================================================================
	}
}